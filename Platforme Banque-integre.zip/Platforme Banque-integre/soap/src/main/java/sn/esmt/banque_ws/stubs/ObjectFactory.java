//
// Ce fichier a été généré par Eclipse Implementation of JAXB, v4.0.2 
// Voir https://eclipse-ee4j.github.io/jaxb-ri 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
//


package sn.esmt.banque_ws.stubs;

import jakarta.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the sn.esmt.banque_ws.stubs package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: sn.esmt.banque_ws.stubs
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AddClientRequest }
     * 
     * @return
     *     the new instance of {@link AddClientRequest }
     */
    public AddClientRequest createAddClientRequest() {
        return new AddClientRequest();
    }

    /**
     * Create an instance of {@link AddClientResponse }
     * 
     * @return
     *     the new instance of {@link AddClientResponse }
     */
    public AddClientResponse createAddClientResponse() {
        return new AddClientResponse();
    }

    /**
     * Create an instance of {@link Client }
     * 
     * @return
     *     the new instance of {@link Client }
     */
    public Client createClient() {
        return new Client();
    }

    /**
     * Create an instance of {@link GetSoldeRequest }
     * 
     * @return
     *     the new instance of {@link GetSoldeRequest }
     */
    public GetSoldeRequest createGetSoldeRequest() {
        return new GetSoldeRequest();
    }

    /**
     * Create an instance of {@link GetSoldeResponse }
     * 
     * @return
     *     the new instance of {@link GetSoldeResponse }
     */
    public GetSoldeResponse createGetSoldeResponse() {
        return new GetSoldeResponse();
    }

    /**
     * Create an instance of {@link AddTransferRequest }
     * 
     * @return
     *     the new instance of {@link AddTransferRequest }
     */
    public AddTransferRequest createAddTransferRequest() {
        return new AddTransferRequest();
    }

    /**
     * Create an instance of {@link AddTransferResponse }
     * 
     * @return
     *     the new instance of {@link AddTransferResponse }
     */
    public AddTransferResponse createAddTransferResponse() {
        return new AddTransferResponse();
    }

    /**
     * Create an instance of {@link AddPaymentRequest }
     * 
     * @return
     *     the new instance of {@link AddPaymentRequest }
     */
    public AddPaymentRequest createAddPaymentRequest() {
        return new AddPaymentRequest();
    }

    /**
     * Create an instance of {@link AddPaymentResponse }
     * 
     * @return
     *     the new instance of {@link AddPaymentResponse }
     */
    public AddPaymentResponse createAddPaymentResponse() {
        return new AddPaymentResponse();
    }

    /**
     * Create an instance of {@link Compte }
     * 
     * @return
     *     the new instance of {@link Compte }
     */
    public Compte createCompte() {
        return new Compte();
    }

}
