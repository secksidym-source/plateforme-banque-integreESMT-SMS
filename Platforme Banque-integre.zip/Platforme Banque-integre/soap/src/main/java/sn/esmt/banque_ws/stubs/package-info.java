//
// Ce fichier a été généré par Eclipse Implementation of JAXB, v4.0.2 
// Voir https://eclipse-ee4j.github.io/jaxb-ri 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
//

@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://esmt.sn/banque-ws", elementFormDefault = jakarta.xml.bind.annotation.XmlNsForm.QUALIFIED)
package sn.esmt.banque_ws.stubs;
