//
// Ce fichier a été généré par Eclipse Implementation of JAXB, v4.0.2 
// Voir https://eclipse-ee4j.github.io/jaxb-ri 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
//


package sn.esmt.banque_ws.stubs;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour anonymous complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>{@code
 * <complexType>
 *   <complexContent>
 *     <restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       <sequence>
 *         <element name="idSource" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         <element name="idDest" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         <element name="montant" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       </sequence>
 *     </restriction>
 *   </complexContent>
 * </complexType>
 * }</pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "idSource",
    "idDest",
    "montant"
})
@XmlRootElement(name = "addTransferRequest")
public class AddTransferRequest {

    protected long idSource;
    protected long idDest;
    protected double montant;

    /**
     * Obtient la valeur de la propriété idSource.
     * 
     */
    public long getIdSource() {
        return idSource;
    }

    /**
     * Définit la valeur de la propriété idSource.
     * 
     */
    public void setIdSource(long value) {
        this.idSource = value;
    }

    /**
     * Obtient la valeur de la propriété idDest.
     * 
     */
    public long getIdDest() {
        return idDest;
    }

    /**
     * Définit la valeur de la propriété idDest.
     * 
     */
    public void setIdDest(long value) {
        this.idDest = value;
    }

    /**
     * Obtient la valeur de la propriété montant.
     * 
     */
    public double getMontant() {
        return montant;
    }

    /**
     * Définit la valeur de la propriété montant.
     * 
     */
    public void setMontant(double value) {
        this.montant = value;
    }

}
