package com.banque.soap.endpoint;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
import sn.esmt.banque_ws.stubs.*;

@Endpoint
public class BanqueEndpoint {

    private static final String NAMESPACE_URI = "http://esmt.sn/banque-ws";

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "addClientRequest")
    @ResponsePayload
    public AddClientResponse addClient(@RequestPayload AddClientRequest request) {
        AddClientResponse response = new AddClientResponse();

        // Simulation de création de client (à connecter à votre base de données ou service)
        Client client = new Client();
        client.setId(1L);
        client.setNom(request.getNom());
        client.setEmail(request.getEmail());

        response.setClient(client);
        response.setMessage("Client créé avec succès !");
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "getSoldeRequest")
    @ResponsePayload
    public GetSoldeResponse getSolde(@RequestPayload GetSoldeRequest request) {
        GetSoldeResponse response = new GetSoldeResponse();

        response.setCompteId(request.getCompteId());
        response.setSolde(150000.0); // Valeur simulée
        response.setType("COURANT");

        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "addTransferRequest")
    @ResponsePayload
    public AddTransferResponse addTransfer(@RequestPayload AddTransferRequest request) {
        AddTransferResponse response = new AddTransferResponse();

        // Logique de transfert entre request.getIdSource() et request.getIdDest()
        response.setSuccess(true);
        response.setMessage("Transfert de " + request.getMontant() + " effectué avec succès.");
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "addPaymentRequest")
    @ResponsePayload
    public AddPaymentResponse addPayment(@RequestPayload AddPaymentRequest request) {
        AddPaymentResponse response = new AddPaymentResponse();

        // Logique de paiement
        response.setSuccess(true);
        response.setMessage("Paiement de " + request.getMontant() + " enregistré (Réf: " + request.getReference() + ").");
        return response;
    }
}
