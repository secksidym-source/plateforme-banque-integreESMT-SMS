package com.banque.soap.rest;

public record ClientRest(String id, String nom, long solde, String devise) {}
