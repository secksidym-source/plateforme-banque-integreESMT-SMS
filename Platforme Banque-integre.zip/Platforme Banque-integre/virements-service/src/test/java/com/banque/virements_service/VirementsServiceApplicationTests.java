package com.banque.virements_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirementsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
