package com.banque.virements_service.service;

import com.fasterxml.jackson.annotation.JsonAlias;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.time.Instant;
import java.util.Map;

@Service
public class VirementService {

    private final RestClient comptes;
    private final RestClient integrationClient;
    private final CircuitBreakerFactory<?, ?> cbFactory;

    // DTO acceptant toutes les variantes de noms JSON envoyées par le serveur MCP
    // et sérialisant toujours vers idSource, idDest, montant pour compte-service
    public record VirementRequest(
        @JsonAlias({"compteSourceId", "sourceId", "idCompteSource", "compteSource"}) Long idSource,
        @JsonAlias({"compteDestinationId", "compteDestId", "destId", "destinationId", "idCompteDest", "compteDestination"}) Long idDest,
        double montant
    ) {}

    public VirementService(RestClient.Builder builder, CircuitBreakerFactory<?, ?> cbFactory) {
        this.comptes = builder.baseUrl("http://compte-service").build();
        // Client HTTP direct (sans LoadBalancer Eureka) pour joindre WSO2 (9090) et n8n (5678)
        this.integrationClient = RestClient.create();
        this.cbFactory = cbFactory;
    }

    public String consulterSolde(Long id) {
        return cbFactory.create("comptes").run(
            () -> comptes.get()
                .uri("/comptes/{id}/solde", id)
                .retrieve()
                .body(String.class),
            erreur -> "{\"compteId\":" + id + ",\"statut\":\"Solde indisponible\"}"
        );
    }

    public String executerVirement(VirementRequest request) {
        // 1. Exécution transactionnelle sur compte-service (POST /comptes/virement)
        String resultatCompte = cbFactory.create("comptes").run(
            () -> comptes.post()
                .uri("/comptes/virement")
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(String.class),
            erreur -> "ERREUR_COMPTES:" + erreur.getMessage()
        );

        // Vérification si compte-service est indisponible ou a refusé le virement (ex. solde insuffisant)
        if (resultatCompte == null || resultatCompte.startsWith("ERREUR_COMPTES:") || resultatCompte.startsWith("Échec")) {
            throw new RuntimeException(resultatCompte != null ? resultatCompte : "Réponse vide de compte-service");
        }

        // 2. Audit SOAP legacy via WSO2 Integrator / Ballerina (port 9090)
        String traceAuditSoap;
        try {
            Map<String, Object> auditPayload = Map.of(
                "compteSourceId", request.idSource(),
                "compteDestinationId", request.idDest(),
                "montant", request.montant()
            );

            traceAuditSoap = integrationClient.post()
                .uri("http://localhost:9090/banque/audit-virement")
                .contentType(MediaType.APPLICATION_JSON)
                .body(auditPayload)
                .retrieve()
                .body(String.class);
        } catch (Exception e) {
            traceAuditSoap = "{\"statut\":\"AUDIT_SOAP_INDISPONIBLE\",\"detail\":\"" + e.getMessage().replace("\"", "'") + "\"}";
        }

        // 3. Déclenchement de la notification client via n8n Webhook (port 5678)
        String statutNotification;
        try {
            Map<String, Object> n8nPayload = Map.of(
                "evenement", "VIREMENT_EFFECTUE",
                "compteSourceId", request.idSource(),
                "compteDestinationId", request.idDest(),
                "montant", request.montant(),
                "devise", "FCFA",
                "referenceSoap", traceAuditSoap != null ? traceAuditSoap : "OK",
                "horodatage", Instant.now().toString()
            );

            integrationClient.post()
                .uri("http://localhost:5678/webhook/virement-effectue")
                .contentType(MediaType.APPLICATION_JSON)
                .body(n8nPayload)
                .retrieve()
                .toBodilessEntity();

            statutNotification = "EMAIL_DECLENCHE_N8N";
        } catch (Exception e) {
            statutNotification = "NOTIFICATION_N8N_INDISPONIBLE";
        }

        // 4. Réponse JSON consolidée retournée au serveur MCP / Claude Desktop
        String resultatEchappe = resultatCompte.replace("\"", "\\\"");
        return String.format(
            "{\"statut\":\"SUCCES\",\"resultatCompte\":\"%s\",\"auditSoap\":%s,\"notification\":\"%s\"}",
            resultatEchappe,
            traceAuditSoap != null ? traceAuditSoap : "{}",
            statutNotification
        );
    }
}
