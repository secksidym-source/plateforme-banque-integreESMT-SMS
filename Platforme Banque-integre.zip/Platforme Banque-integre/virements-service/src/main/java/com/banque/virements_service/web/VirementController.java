package com.banque.virements_service.web;

import com.banque.virements_service.service.VirementService;
import com.banque.virements_service.service.VirementService.VirementRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/virements")
public class VirementController {

    private final VirementService service;

    public VirementController(VirementService service) {
        this.service = service;
    }

    @GetMapping(value = "/solde/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> verifierSolde(@PathVariable Long id) {
        return ResponseEntity.ok(service.consulterSolde(id));
    }

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> lancerVirement(@RequestBody Map<String, Object> raw) {
        System.out.println(">>> PAYLOAD BRUT RECU DU MCP : " + raw);

        Long idSource = extraireLong(raw, "idSource", "compteSourceId", "sourceId", "idCompteSource", "compteSource", "source", "from", "de");
        Long idDest = extraireLong(raw, "idDest", "compteDestinationId", "compteDestId", "destId", "destinationId", "idCompteDest", "compteDestination", "destination", "dest", "to", "vers");
        double montant = raw.get("montant") != null ? Double.parseDouble(raw.get("montant").toString()) : 0.0;

        try {
            String resultat = service.executerVirement(new VirementRequest(idSource, idDest, montant));
            return ResponseEntity.ok(resultat);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of(
                    "statut", "ECHEC",
                    "payloadRecu", raw,
                    "message", e.getMessage()
                ));
        }
    }

    private Long extraireLong(Map<String, Object> map, String... cles) {
        for (String cle : cles) {
            if (map.containsKey(cle) && map.get(cle) != null) {
                return Long.valueOf(map.get(cle).toString());
            }
        }
        return null;
    }
}
