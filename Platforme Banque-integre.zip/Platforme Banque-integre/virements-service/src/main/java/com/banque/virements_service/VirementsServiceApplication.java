package com.banque.virements_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirementsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirementsServiceApplication.class, args);
	}

}
