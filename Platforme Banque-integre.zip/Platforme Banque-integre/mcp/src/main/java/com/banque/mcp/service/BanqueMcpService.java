package com.banque.mcp.service;

import io.modelcontextprotocol.server.McpServerFeatures;
import io.modelcontextprotocol.spec.McpSchema;
import org.springaicommunity.mcp.annotation.McpArg;
import org.springaicommunity.mcp.annotation.McpPrompt;
import org.springaicommunity.mcp.annotation.McpTool;
import org.springaicommunity.mcp.annotation.McpToolParam;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

@Service
public class BanqueMcpService {

    private final RestClient gatewayClient;

    public BanqueMcpService(@Value("${banque.gateway.url:http://localhost:8080}") String gatewayUrl) {
        this.gatewayClient = RestClient.builder()
            .baseUrl(gatewayUrl)
            .build();
    }

    // =========================================================================
    // 1. TOOLS (Outils MCP routés via l'API Gateway sur le port 8080)
    // =========================================================================

    @McpTool(name = "consulter_solde", description = "Consulte le solde et le type d'un compte bancaire à partir de son identifiant.")
    public String consulterSolde(
        @McpToolParam(description = "Identifiant numérique du compte bancaire (ex: 1, 2)", required = true) Long compteId
    ) {
        try {
            Map[] comptes = gatewayClient.get()
                .uri("/comptes")
                .retrieve()
                .body(Map[].class);

            if (comptes != null) {
                for (Map<String, Object> c : comptes) {
                    Object idObj = c.get("id");
                    if (idObj != null && String.valueOf(idObj).equals(String.valueOf(compteId))) {
                        Object solde = c.get("solde");
                        Object type = c.getOrDefault("type", "COURANT");
                        Object devise = c.getOrDefault("devise", "FCFA");
                        return String.format("Compte %s (%s) : solde actuel de %s %s.", compteId, type, solde, devise);
                    }
                }
            }
            return "Aucun compte trouvé avec l'identifiant " + compteId + ".";
        } catch (Exception e) {
            return "Erreur lors de la consultation du compte via la Gateway : " + e.getMessage();
        }
    }

    @McpTool(name = "effectuer_virement", description = "Effectue un virement bancaire entre deux comptes. Nécessite une confirmation explicite de l'utilisateur.")
    public String effectuerVirement(
        @McpToolParam(description = "Identifiant du compte source à débiter", required = true) Long compteSource,
        @McpToolParam(description = "Identifiant du compte destinataire à créditer", required = true) Long compteDestination,
        @McpToolParam(description = "Montant du virement en FCFA", required = true) Double montant,
        @McpToolParam(description = "Doit être true uniquement après validation explicite de l'utilisateur", required = true) Boolean confirmationUtilisateur
    ) {
        if (confirmationUtilisateur == null || !confirmationUtilisateur) {
            return "CONFIRMATION_REQUISE : Veuillez demander une confirmation explicite à l'utilisateur avant d'exécuter ce virement de "
                + montant + " FCFA du compte " + compteSource + " vers le compte " + compteDestination + ".";
        }

        if (montant == null || montant <= 0) {
            return "Erreur : le montant du virement doit être strictement positif.";
        }

        try {
            Map<String, Object> payload = Map.of(
                "compteSourceId", compteSource,
                "compteDestinationId", compteDestination,
                "montant", montant
            );

            String reponse = gatewayClient.post()
                .uri("/virements")
                .body(payload)
                .retrieve()
                .body(String.class);

            return "Virement exécuté avec succès via la Gateway : " + reponse;
        } catch (Exception e) {
            return "Échec du virement via la Gateway : " + e.getMessage();
        }
    }

    @McpTool(name = "ajouter_client", description = "Crée un nouveau client dans le système bancaire.")
    public String ajouterClient(
        @McpToolParam(description = "Identifiant unique du client (ex: 4)", required = true) String id,
        @McpToolParam(description = "Nom complet du client", required = true) String nom,
        @McpToolParam(description = "Solde initial du client (défaut: 0)", required = false) Double solde,
        @McpToolParam(description = "Devise du compte (défaut: XOF)", required = false) String devise
    ) {
        try {
            Map<String, Object> nouveauClient = Map.of(
                "id", id,
                "nom", nom,
                "solde", solde != null ? solde : 0,
                "devise", (devise != null && !devise.isBlank()) ? devise : "XOF"
            );

            return gatewayClient.post()
                .uri("/clients")
                .body(nouveauClient)
                .retrieve()
                .body(String.class);
        } catch (Exception e) {
            return "Erreur lors de la création du client via la Gateway : " + e.getMessage();
        }
    }

    // =========================================================================
    // 2. PROMPT (Modèle d'analyse financière)
    // =========================================================================

    @McpPrompt(name = "analyse_compte", description = "Génère une analyse financière complète d'un client et de son compte.")
    public McpSchema.GetPromptResult analyseCompte(
        @McpArg(name = "clientId", description = "Identifiant du client à analyser", required = true) String clientId
    ) {
        String instruction = String.format("""
                Analyse la situation financière du client %s :
                1. Lis sa fiche via la ressource banque://clients/%s.
                2. Vérifie son solde via l'outil consulter_solde.
                3. Présente une synthèse claire en FCFA.
                """, clientId, clientId);

        return new McpSchema.GetPromptResult(
            "Analyse financière du client " + clientId,
            List.of(new McpSchema.PromptMessage(
                McpSchema.Role.USER,
                new McpSchema.TextContent(instruction)
            ))
        );
    }

    // =========================================================================
    // 3. RESOURCES & RESOURCE TEMPLATES (Fiches clients via la Gateway)
    // =========================================================================

    @Bean
    public List<McpServerFeatures.SyncResourceSpecification> banqueResources() {
        var resource = new McpSchema.Resource(
            "banque://clients/1",
            "Fiche Client",
            "Informations détaillées du client 1",
            "application/json",
            null
        );

        var spec = new McpServerFeatures.SyncResourceSpecification(resource, (exchange, request) -> {
            String json = gatewayClient.get()
                .uri("/clients/1")
                .retrieve()
                .body(String.class);

            return new McpSchema.ReadResourceResult(
                List.of(new McpSchema.TextResourceContents(request.uri(), "application/json", json))
            );
        });

        return List.of(spec);
    }

    @Bean
    public List<McpServerFeatures.SyncResourceTemplateSpecification> banqueResourceTemplates() {
        var template = new McpSchema.ResourceTemplate(
            "banque://clients/{id}",
            "Fiche Client Dynamique",
            "Informations détaillées d'un client bancaire par ID",
            "application/json",
            null
        );

        var spec = new McpServerFeatures.SyncResourceTemplateSpecification(template, (exchange, request) -> {
            String uri = request.uri();
            String id = uri.substring(uri.lastIndexOf('/') + 1);

            String json = gatewayClient.get()
                .uri("/clients/{id}", id)
                .retrieve()
                .body(String.class);

            return new McpSchema.ReadResourceResult(
                List.of(new McpSchema.TextResourceContents(uri, "application/json", json))
            );
        });

        return List.of(spec);
    }
}
