# Plateforme Banque Intégrée

Plateforme de services bancaires orientée microservices, intégration d'entreprise et orchestration par agent IA (MCP). Elle assemble les briques des TP 1 à 5 autour d'un scénario complet : consultation de solde, exécution de virement, audit SOAP, notification client via `n8n` et publication d'événement (Kafka en option/bonus).

## Architecture globale

* **Découverte de services** : Spring Cloud Netflix Eureka (`8761`)
* **Point d'entrée** : Spring Cloud Gateway (`8080`)
* **Microservices métier** : `clients-service`, `compte-service` (instances `8081` et `8082`), `virements-service`
* **Intégration & Audit** : WSO2 Micro Integrator, service SOAP (`8085`, namespace `http://esmt.sn/banque-ws`) et service Ballerina exposant `/banque/audit-virement`
* **Workflow & Événements** : `n8n` (`5678`) pour les notifications clients (+ Kafka en bonus)
* **Agent IA** : Serveur MCP connecté à Claude Desktop

## Prérequis

* Docker & Docker Compose
* Java / Maven (si compilation ou exécution locale hors conteneur)
* Ballerina CLI (`bal`) & WSO2 Micro Integrator (si exécutés sur l'hôte)
* Claude Desktop configuré avec le serveur MCP

## Démarrage rapide

1. **Préparer les variables d'environnement** :
   ```bash
  