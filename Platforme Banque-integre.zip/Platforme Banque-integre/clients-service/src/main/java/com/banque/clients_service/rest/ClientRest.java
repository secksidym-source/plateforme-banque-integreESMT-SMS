package com.banque.clients_service.rest;

public record ClientRest(String id, String nom, long solde, String devise) {}
