package com.banque.clients_service.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;

@RestController
@RequestMapping("/clients")
@Tag(name = "Clients", description = "API Banque - Gestion des clients")
public class ClientController {

    private final ClientRestService service;

    public ClientController(ClientRestService service) {
        this.service = service;
    }

    @GetMapping("/{id}")
    @Operation(summary = "Consulter un client")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Client trouvé"),
        @ApiResponse(responseCode = "404", description = "Client inconnu")
    })
    public ResponseEntity<ClientRest> lire(@PathVariable String id) {
        return service.trouver(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Créer un client")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Client créé")
    })
    public ResponseEntity<ClientRest> creer(@RequestBody ClientRest c) {
        ClientRest cree = service.creer(c);
        return ResponseEntity.created(URI.create("/clients/" + cree.id()))
            .body(cree);
    }
}

