package com.banque.clients_service.rest;

import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class ClientRestService {
    private final Map<String, ClientRest> clients = new ConcurrentHashMap<>();

    public ClientRestService() {
        // Données initiales pour tester immédiatement GET /clients/C001
        clients.put("C001", new ClientRest("C001", "Awa Diop", 150000L, "XOF"));
        clients.put("C002", new ClientRest("C002", "Amadou Diallo", 250000L, "XOF"));
    }

    public Optional<ClientRest> trouver(String id) {
        return Optional.ofNullable(clients.get(id));
    }

    public ClientRest creer(ClientRest c) {
        String devise = (c.devise() == null || c.devise().isBlank()) ? "XOF" : c.devise();
        ClientRest nouveau = new ClientRest(c.id(), c.nom(), c.solde(), devise);
        clients.put(nouveau.id(), nouveau);
        return nouveau;
    }
}
