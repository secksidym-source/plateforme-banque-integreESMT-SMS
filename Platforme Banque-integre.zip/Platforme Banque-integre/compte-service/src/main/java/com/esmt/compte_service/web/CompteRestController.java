package com.esmt.compte_service.web;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comptes")
public class CompteRestController {

    @Value("${server.port}")
    private String port;

    public static class Compte {
        private Long id;
        private double solde;
        private String type;

        public Compte(Long id, double solde, String type) {
            this.id = id;
            this.solde = solde;
            this.type = type;
        }

        public Long getId() { return id; }
        public double getSolde() { return solde; }
        public void setSolde(double solde) { this.solde = solde; }
        public String getType() { return type; }
    }

    // DTO retourné par GET /comptes/{id}/solde incluant le port de l'instance
    public record SoldeResponse(Long compteId, double solde, String type, String instancePort) {}

    // Liste simulée en mémoire
    private static List<Compte> comptesList = List.of(
        new Compte(1L, 150000.0, "COURANT"),
        new Compte(2L, 250000.0, "EPARGNE"),
        new Compte(3L, 50000.0, "COURANT")
    );

    @GetMapping
    public List<Compte> listComptes() {
        return comptesList;
    }

    // Nouvel endpoint appelé par virements-service via RestClient @LoadBalanced
    @GetMapping("/{id}/solde")
    public ResponseEntity<SoldeResponse> getSolde(@PathVariable Long id) {
        return comptesList.stream()
            .filter(c -> c.getId().equals(id))
            .findFirst()
            .map(c -> ResponseEntity.ok(new SoldeResponse(c.getId(), c.getSolde(), c.getType(), port)))
            .orElse(ResponseEntity.notFound().build());
    }

    // Objet DTO pour recevoir les détails du virement
    public static class VirementRequest {
        private Long idSource;
        private Long idDest;
        private double montant;

        public Long getIdSource() { return idSource; }
        public void setIdSource(Long idSource) { this.idSource = idSource; }

        public Long getIdDest() { return idDest; }
        public void setIdDest(Long idDest) { this.idDest = idDest; }

        public double getMontant() { return montant; }
        public void setMontant(double montant) { this.montant = montant; }
    }

    // Endpoint POST pour exécuter le virement
    @PostMapping("/virement")
    public String effectuerVirement(@RequestBody VirementRequest request) {
        System.out.println(">>> RECU VIREMENT : idSource=" + request.getIdSource() + ", idDest=" + request.getIdDest() + ", montant=" + request.getMontant());
        Compte source = comptesList.stream()
            .filter(c -> c.getId().equals(request.getIdSource()))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Compte source introuvable"));

        Compte dest = comptesList.stream()
            .filter(c -> c.getId().equals(request.getIdDest()))
            .findFirst()
            .orElseThrow(() -> new RuntimeException("Compte destination introuvable"));

        if (source.getSolde() < request.getMontant()) {
            return "Échec du virement : Solde insuffisant sur le compte " + source.getId();
        }

        source.setSolde(source.getSolde() - request.getMontant());
        dest.setSolde(dest.getSolde() + request.getMontant());

        return "Virement de " + request.getMontant() + " effectué avec succès du compte "
            + source.getId() + " vers le compte " + dest.getId();
    }
}
