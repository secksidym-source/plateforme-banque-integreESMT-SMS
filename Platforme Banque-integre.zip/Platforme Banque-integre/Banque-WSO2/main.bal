import ballerina/http;
xmlns "http://esmt.sn/banque-ws" as ns2;

type AuditVirementRequest record {|
    int|string compteSourceId;
    int|string compteDestinationId;
    decimal|float|int|string montant;
|};

listener http:Listener httpDefaultListener = new (9090);

service /banque on httpDefaultListener {

    // 1. Consultation du solde d'un compte via le service SOAP (port 8085)
    resource function get compte/[string code]() returns json|error {
        do {
            http:Client soapClient = check new ("http://localhost:8085");

            string soapPayload = string `
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ban="http://esmt.sn/banque-ws">
                    <soapenv:Header/>
                    <soapenv:Body>
                        <ban:getSoldeRequest>
                            <ban:compteId>${code}</ban:compteId>
                        </ban:getSoldeRequest>
                    </soapenv:Body>
                </soapenv:Envelope>`;

            xml soapResponse = check soapClient->post("/ws", soapPayload, {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": ""
            });

            // Extraction de <compteId>, <solde> et <type> depuis getSoldeResponse
            xml compteEl = soapResponse/*/*/*;
            string codeVal = (compteEl/*[0]).data();
            string soldeVal = (compteEl/*[1]).data();
            string typeVal = (compteEl/*[2]).data();

            json jsonResponse = {
                "code": codeVal,
                "solde": check decimal:fromString(soldeVal),
                "type": typeVal
            };

            return jsonResponse;

        } on fail error err {
            return error("Erreur lors de la conversion ou de l'appel SOAP : " + err.message());
        }
    }

    // 2. Audit et enregistrement d'un virement via le service SOAP (appelé par virements-service)
    resource function post audit\-virement(@http:Payload AuditVirementRequest payload) returns json|error {
        do {
            string idSource = ( payload.compteSourceId).toString();
            string idDestination = ( payload.compteDestinationId).toString();
            string montant = ( payload.montant).toString();

            http:Client soapClient = check new ("http://localhost:8085");

            string soapPayload = string `
                <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ban="http://esmt.sn/banque-ws">
                    <soapenv:Header/>
                    <soapenv:Body>
                        <ban:addTransferRequest>
                            <ban:idSource>${idSource}</ban:idSource>
                            <ban:idDest>${idDestination}</ban:idDest>
                            <ban:montant>${montant}</ban:montant>
                        </ban:addTransferRequest>
                    </soapenv:Body>
                </soapenv:Envelope>`;

            xml soapResponse = check soapClient->post("/ws", soapPayload, {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": ""
            });

           // Extraction sécurisée depuis addTransferResponse
xml addTransferResp = soapResponse/**/<ns2:addTransferResponse>;
string successRaw = (addTransferResp/<ns2:success>).data().trim();
string messageVal = (addTransferResp/<ns2:message>).data().trim();

boolean|error parsedBool = boolean:fromString(successRaw.toLowerAscii());
boolean soapSuccess = parsedBool is boolean
    ? parsedBool
    : (successRaw.toLowerAscii() == "ok" || successRaw == "1");

return {
    "statut": "AUDITE_VIA_SOAP",
    "soapSuccess": soapSuccess,
    "soapMessage": messageVal,
    "compteSource": idSource,
    "compteDestination": idDestination,
    "montant": montant
};

        } on fail error err {
            return error("Erreur lors de l'appel SOAP addTransferRequest : " + err.message());
        }
    }
}