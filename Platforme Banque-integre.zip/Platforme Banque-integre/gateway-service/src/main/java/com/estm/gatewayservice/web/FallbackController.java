package com.estm.gatewayservice.web;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallbackController {

    @GetMapping("/fallback-comptes")
    public ResponseEntity<String> compteServiceFallback() {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
            .body("⚠️ Le service des comptes est actuellement indisponible. Veuillez réessayer plus tard. (Fallback actif)");
    }
}
